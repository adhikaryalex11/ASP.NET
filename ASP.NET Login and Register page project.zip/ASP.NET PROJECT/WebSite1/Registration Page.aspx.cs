﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

public partial class Login_Page : System.Web.UI.Page
{
    MySqlDBHelper mdb = new MySqlDBHelper();
    protected void Page_Load(object sender, EventArgs e)
    {
        UnobtrusiveValidationMode = UnobtrusiveValidationMode.None;
    }



    protected void Button1_Click(object sender, EventArgs e)
    {
      string fn, ln, uname, email, pn, Country, pm, pwd;
        fn = Text
 
        string select = 
        string insert = string.Format(@" insert into user values(null,'(0)','(1)','(2)','(3)','(4)','(5)')",
                 FirstName, LastName, UserID, EmailID, PhoneNumber, Country, PaymentMethod, Password);
        if (Convert.ToInt32(mdb.ExecuteScalar(select)) > 0 {
            Label3.Text = "The UserID has been used before";
            }else {
            if (mdb.ExecuteInsertUpdateDelete(insert) > 0)
            {
                Response.Write("<script>alert('Congratulations! Resgistration Sucessful');window.location.href='Login.aspx'</script>");
            }

            }
            }

    protected void TextBox1_TextChanged(object sender, EventArgs e)
    {

    }

    protected void TextBox1_TextChanged1(object sender, EventArgs e)
    {

    }


    